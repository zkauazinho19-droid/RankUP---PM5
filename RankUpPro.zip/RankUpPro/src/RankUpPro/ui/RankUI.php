<?php

declare(strict_types=1);

namespace RankUpPro\ui;

use pocketmine\player\Player;
use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\ModalForm;
use RankUpPro\Main;

class RankUI {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function openMainUI(Player $player): void {
        $dataManager = $this->plugin->getPlayerDataManager();
        $rankManager = $this->plugin->getRankManager();
        $econManager = $this->plugin->getEconomyManager();

        $rankId = $dataManager->getPlayerRank($player->getName());
        $rank = $rankManager->getRank($rankId);
        $balance = $econManager->getBalance($player);
        $nextRankId = $rankManager->getNextRank($rankId);
        $nextRank = $nextRankId !== null ? $rankManager->getRank($nextRankId) : null;

        if ($rank === null) return;

        $tag = $rank['tag'] ?? "§7[{$rankId}]";
        $progressBar = $rankManager->getProgressBar($rankId);
        $currentIdx = $rankManager->getRankIndex($rankId) + 1;
        $totalRanks = $rankManager->getTotalRanks();

        $form = new SimpleForm(function(Player $player, ?int $data) use ($nextRankId): void {
            if ($data === null) return;
            switch ($data) {
                case 0:
                    $this->openRankUpConfirm($player);
                    break;
                case 1:
                    $this->openRankListUI($player);
                    break;
                case 2:
                    $this->openMyRankUI($player);
                    break;
            }
        });

        $form->setTitle("§l§6✦ §b§lRANKUP PRO §6✦");

        $content = "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§f  Rank Atual: {$tag}\n";
        $content .= "§f  Saldo: §a" . $econManager->formatMoney($balance) . "\n";
        $content .= "§f\n";
        $content .= "§f  Progresso: §e{$currentIdx}§7/§e{$totalRanks}\n";
        $content .= "  {$progressBar}\n";
        $content .= "§f\n";

        if ($nextRank !== null) {
            $nextPrice = (float)($nextRank['price'] ?? 0);
            $nextTag = $nextRank['tag'] ?? "§7[{$nextRankId}]";
            $canAfford = $balance >= $nextPrice;
            $needed = max(0, $nextPrice - $balance);
            
            $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
            $content .= "§r§f\n";
            $content .= "§f  Próximo Rank: {$nextTag}\n";
            $content .= "§f  Preço: §e" . $econManager->formatMoney($nextPrice) . "\n";
            
            if ($canAfford) {
                $content .= "§f\n";
                $content .= "§a  ✔ Você pode subir de rank!\n";
            } else {
                $content .= "§f  Faltam: §c" . $econManager->formatMoney($needed) . "\n";
            }
            
            $content .= "§f\n";
            $content .= "§e  🎁 Recompensas:\n";
            $rewards = $this->plugin->getRewardManager()->getRewardsDisplay($nextRankId);
            if ($rewards !== "§7Nenhuma recompensa") {
                foreach (explode("\n", $rewards) as $line) {
                    $content .= "  {$line}\n";
                }
            } else {
                $content .= "  §7Nenhuma recompensa\n";
            }
        } else {
            $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
            $content .= "§r§f\n";
            $content .= "§6§l  ★ RANK MÁXIMO ALCANÇADO! ★\n";
            $content .= "§r§7  Parabéns por chegar ao topo!\n";
        }

        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";

        $form->setContent($content);

        if ($nextRank !== null) {
            $nextPrice = (float)($nextRank['price'] ?? 0);
            $canAfford = $balance >= $nextPrice;
            $btnColor = $canAfford ? "§a§l" : "§c§l";
            $form->addButton(
                "{$btnColor}⬆ SUBIR DE RANK\n§r§7Clique para evoluir",
                SimpleForm::IMAGE_TYPE_PATH,
                "textures/ui/upgrade_arrow"
            );
        } else {
            $form->addButton(
                "§6§l★ RANK MÁXIMO!\n§r§7Você está no topo!",
                SimpleForm::IMAGE_TYPE_PATH,
                "textures/ui/icon_best3"
            );
        }

        $form->addButton(
            "§e§l📋 LISTA DE RANKS\n§r§7Ver todos os ranks",
            SimpleForm::IMAGE_TYPE_PATH,
            "textures/ui/book_writable"
        );

        $form->addButton(
            "§b§l👤 MEU PERFIL\n§r§7Estatísticas detalhadas",
            SimpleForm::IMAGE_TYPE_PATH,
            "textures/ui/icon_steve"
        );

        $player->sendForm($form);
    }

    public function openRankUpConfirm(Player $player): void {
        $dataManager = $this->plugin->getPlayerDataManager();
        $rankManager = $this->plugin->getRankManager();
        $econManager = $this->plugin->getEconomyManager();

        $rankId = $dataManager->getPlayerRank($player->getName());
        $nextRankId = $rankManager->getNextRank($rankId);

        if ($nextRankId === null) {
            $player->sendMessage($this->plugin->getConfig()->get("messages")["rankup-max"]);
            return;
        }

        $nextRank = $rankManager->getRank($nextRankId);
        if ($nextRank === null) return;

        $nextTag = $nextRank['tag'] ?? "§7[{$nextRankId}]";
        $price = (float)($nextRank['price'] ?? 0);
        $balance = $econManager->getBalance($player);
        $canAfford = $balance >= $price;

        $form = new ModalForm(function(Player $player, ?bool $data) use ($nextRankId, $price, $canAfford): void {
            if ($data === null || !$data) {
                $this->openMainUI($player);
                return;
            }
            if (!$canAfford) {
                $player->sendMessage("§c✘ Você não tem dinheiro suficiente!");
                $this->openMainUI($player);
                return;
            }
            $this->processRankUp($player);
        });

        $form->setTitle("§l§a⬆ CONFIRMAR RANKUP");
        
        $content = "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§f  Você deseja subir para:\n";
        $content .= "  {$nextTag}\n";
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§f  Custo: §e" . $econManager->formatMoney($price) . "\n";
        $content .= "§f  Seu saldo: §a" . $econManager->formatMoney($balance) . "\n";
        $content .= "§f\n";
        
        if ($canAfford) {
            $content .= "§a  ✔ Você TEM dinheiro suficiente!\n";
        } else {
            $needed = $price - $balance;
            $content .= "§c  ✘ Faltam: " . $econManager->formatMoney($needed) . "\n";
        }
        
        $content .= "§f\n";
        $content .= "§e  🎁 Recompensas que você receberá:\n";
        $content .= "§f\n";
        $rewards = $this->plugin->getRewardManager()->getRewardsDisplay($nextRankId);
        foreach (explode("\n", $rewards) as $line) {
            $content .= "  {$line}\n";
        }
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";

        $form->setContent($content);
        $form->setButton1("§a§l✔ CONFIRMAR");
        $form->setButton2("§c§l✘ CANCELAR");

        $player->sendForm($form);
    }

    public function processRankUp(Player $player): void {
        $dataManager = $this->plugin->getPlayerDataManager();
        $rankManager = $this->plugin->getRankManager();
        $econManager = $this->plugin->getEconomyManager();
        $messages = $this->plugin->getConfig()->get("messages", []);
        $prefix = $messages['prefix'] ?? "§8[§bRank§8] §r";

        $rankId = $dataManager->getPlayerRank($player->getName());
        $nextRankId = $rankManager->getNextRank($rankId);

        if ($nextRankId === null) {
            $msg = str_replace('{player}', $player->getName(), $messages['rankup-max'] ?? "§eVocê já está no rank máximo!");
            $player->sendMessage($prefix . $msg);
            return;
        }

        $nextRank = $rankManager->getRank($nextRankId);
        if ($nextRank === null) return;

        $price = (float)($nextRank['price'] ?? 0);
        $balance = $econManager->getBalance($player);

        if ($balance < $price) {
            $msg = $messages['rankup-no-money'] ?? "§cVocê precisa de §e{price} {currency}§c para subir!";
            $msg = str_replace(
                ['{price}', '{currency}', '{balance}'],
                [$econManager->formatMoney($price), $econManager->getCurrencyName(), $econManager->formatMoney($balance)],
                $msg
            );
            $player->sendMessage($prefix . $msg);
            return;
        }

        $econManager->removeBalance($player, $price);
        $rankManager->setPlayerRank($player, $nextRankId);

        $nextTag = $nextRank['tag'] ?? "§7[{$nextRankId}]";
        $rankColor = $nextRank['scoreboard-color'] ?? '§7';
        $msg = $messages['rankup-success'] ?? "§aParabéns! Você subiu para {rank}!";
        $msg = str_replace(
            ['{rank}', '{rank-color}', '{tag}'],
            [$nextRankId, $rankColor, $nextTag],
            $msg
        );
        $player->sendMessage($prefix . $msg);

        $player->sendTitle(
            "§l§6✦ §a§lRANK UP! §6✦",
            "§7Você agora é {$nextTag}",
            10, 60, 10
        );

        $player->getWorld()->addSound($player->getPosition(), new \pocketmine\world\sound\XpLevelUpSound());

        $rankManager->executeRankupCommands($player, $nextRankId);
        $this->plugin->getScoreboardManager()->updateScoreboard($player);

        $this->openRankUpSuccess($player, $nextRankId);
    }

    public function openRankUpSuccess(Player $player, string $newRankId): void {
        $rankManager = $this->plugin->getRankManager();
        $rank = $rankManager->getRank($newRankId);
        if ($rank === null) return;

        $nextRankId = $rankManager->getNextRank($newRankId);

        $form = new ModalForm(function(Player $player, ?bool $data): void {
            $this->openMainUI($player);
        });

        $tag = $rank['tag'] ?? "§7[{$newRankId}]";

        $form->setTitle("§l§6✦ §a§lRANK UP! §6✦");

        $content = "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§a§l  ✔ PARABÉNS, §f{$player->getName()}§a§l!\n";
        $content .= "§r§f\n";
        $content .= "§f  Você agora é:\n";
        $content .= "  {$tag}\n";
        $content .= "§f\n";

        if ($nextRankId !== null) {
            $nextRank = $rankManager->getRank($nextRankId);
            $nextPrice = $nextRank !== null ? $this->plugin->getEconomyManager()->formatMoney((float)($nextRank['price'] ?? 0)) : "N/A";
            $nextTag = $nextRank['tag'] ?? "§7[{$nextRankId}]";
            $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
            $content .= "§r§f\n";
            $content .= "§e  Próximo objetivo:\n";
            $content .= "  {$nextTag}\n";
            $content .= "§f  Preço: §e{$nextPrice}\n";
            $content .= "§f\n";
            $content .= "§e  🎁 Próximas recompensas:\n";
            $rewards = $this->plugin->getRewardManager()->getRewardsDisplay($nextRankId);
            foreach (explode("\n", $rewards) as $line) {
                $content .= "  {$line}\n";
            }
        } else {
            $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
            $content .= "§r§f\n";
            $content .= "§6§l  ★ RANK MÁXIMO ALCANÇADO! ★\n";
            $content .= "§r§7  Você chegou ao topo!\n";
        }

        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";
        $form->setContent($content);
        $form->setButton1("§a§l✔ CONTINUAR");
        $form->setButton2("§7Fechar");

        $player->sendForm($form);
    }

    public function openRankListUI(Player $player): void {
        $rankManager = $this->plugin->getRankManager();
        $dataManager = $this->plugin->getPlayerDataManager();
        $econManager = $this->plugin->getEconomyManager();
        $ranks = $rankManager->getRanks();
        $playerRankId = $dataManager->getPlayerRank($player->getName());
        $playerRankIndex = $rankManager->getRankIndex($playerRankId);

        $form = new SimpleForm(function(Player $player, ?int $data) use ($ranks): void {
            if ($data === null) {
                $this->openMainUI($player);
                return;
            }
            $rankIds = array_keys($ranks);
            if (isset($rankIds[$data])) {
                $this->openRankDetailUI($player, $rankIds[$data]);
            }
        });

        $form->setTitle("§l§e📋 LISTA DE RANKS");

        $totalRanks = count($ranks);
        $content = "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§f  Total de ranks: §e{$totalRanks}\n";
        $content .= "§f  Seu rank: §f" . ($rankManager->getRank($playerRankId)['tag'] ?? $playerRankId) . "\n";
        $content .= "§f\n";
        $content .= "§7  Clique em um rank para ver detalhes\n";
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";
        $form->setContent($content);

        foreach ($ranks as $rankId => $rankData) {
            $rankIndex = $rankManager->getRankIndex($rankId);
            $tag = $rankData['tag'] ?? "§7[{$rankId}]";
            $price = (float)($rankData['price'] ?? 0);

            $isCurrentRank = ($rankId === $playerRankId);
            $isUnlocked = ($rankIndex <= $playerRankIndex);

            if ($isCurrentRank) {
                $statusIcon = "§a§l◀ ATUAL";
            } elseif ($isUnlocked) {
                $statusIcon = "§2✔ Desbloqueado";
            } else {
                $statusIcon = "§c🔒 Bloqueado";
            }
            
            $priceStr = $price > 0 ? "§e" . $econManager->formatMoney($price) : "§6INICIAL";

            $btnLabel = "{$tag} {$statusIcon}\n§r§7Preço: {$priceStr}";

            $form->addButton($btnLabel, SimpleForm::IMAGE_TYPE_PATH, "textures/ui/icon_steve");
        }

        $player->sendForm($form);
    }

    public function openRankDetailUI(Player $player, string $rankId): void {
        $rankManager = $this->plugin->getRankManager();
        $dataManager = $this->plugin->getPlayerDataManager();
        $econManager = $this->plugin->getEconomyManager();

        $rank = $rankManager->getRank($rankId);
        if ($rank === null) return;

        $playerRankId = $dataManager->getPlayerRank($player->getName());
        $playerRankIndex = $rankManager->getRankIndex($playerRankId);
        $rankIndex = $rankManager->getRankIndex($rankId);

        $form = new ModalForm(function(Player $player, ?bool $data): void {
            $this->openRankListUI($player);
        });

        $tag = $rank['tag'] ?? "§7[{$rankId}]";
        $price = (float)($rank['price'] ?? 0);
        $perms = $rank['permissions'] ?? [];
        $isUnlocked = ($rankIndex <= $playerRankIndex);
        $isCurrent = ($rankId === $playerRankId);

        if ($isCurrent) {
            $status = "§a§l★ SEU RANK ATUAL";
        } elseif ($isUnlocked) {
            $status = "§2✔ Desbloqueado";
        } else {
            $status = "§c🔒 Bloqueado";
        }

        $content = "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§f  Rank: {$tag}\n";
        $content .= "§f  Status: {$status}\n";
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§f  Preço: " . ($price > 0 ? "§e" . $econManager->formatMoney($price) : "§6Rank Inicial") . "\n";
        $content .= "§f  Posição: §7" . ($rankIndex + 1) . "º de " . $rankManager->getTotalRanks() . "\n";
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§e  🎁 Recompensas:\n";
        $content .= "§f\n";
        $rewards = $this->plugin->getRewardManager()->getRewardsDisplay($rankId);
        foreach (explode("\n", $rewards) as $line) {
            $content .= "  {$line}\n";
        }
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§b  Permissões:\n";
        if (empty($perms)) {
            $content .= "  §7Nenhuma permissão especial\n";
        } else {
            foreach (array_slice($perms, 0, 5) as $perm) {
                $content .= "  §8• §7{$perm}\n";
            }
            if (count($perms) > 5) {
                $content .= "  §7... e mais " . (count($perms) - 5) . " permissões\n";
            }
        }
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";

        $form->setTitle("§l§b🔍 DETALHES DO RANK");
        $form->setContent($content);
        $form->setButton1("§7← Voltar");
        $form->setButton2("§7Fechar");

        $player->sendForm($form);
    }

    public function openMyRankUI(Player $player): void {
        $dataManager = $this->plugin->getPlayerDataManager();
        $rankManager = $this->plugin->getRankManager();
        $econManager = $this->plugin->getEconomyManager();

        $rankId = $dataManager->getPlayerRank($player->getName());
        $rank = $rankManager->getRank($rankId);
        $balance = $econManager->getBalance($player);
        $totalRankups = $dataManager->getTotalRankups($player->getName());
        $nextRankId = $rankManager->getNextRank($rankId);
        $progressBar = $rankManager->getProgressBar($rankId);
        $currentIdx = $rankManager->getRankIndex($rankId) + 1;
        $totalRanks = $rankManager->getTotalRanks();

        $form = new ModalForm(function(Player $player, ?bool $data): void {
            $this->openMainUI($player);
        });

        $tag = $rank['tag'] ?? "§7[{$rankId}]";

        $content = "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§f  Jogador: §b{$player->getName()}\n";
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§f  Rank: {$tag}\n";
        $content .= "§f  Progresso: §e{$currentIdx}§7/§e{$totalRanks}\n";
        $content .= "  {$progressBar}\n";
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§f  {$econManager->getCurrencyName()}: §a" . $econManager->formatMoney($balance) . "\n";
        $content .= "§f  Rankups feitos: §e{$totalRankups}\n";
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";

        if ($nextRankId !== null) {
            $nextRank = $rankManager->getRank($nextRankId);
            $nextPrice = $nextRank !== null ? (float)($nextRank['price'] ?? 0) : 0;
            $nextTag = $nextRank['tag'] ?? "§7[{$nextRankId}]";
            $needed = max(0, $nextPrice - $balance);
            $content .= "§f  Próximo: {$nextTag}\n";
            $content .= "§f  Faltam: §c" . $econManager->formatMoney($needed) . "\n";
        } else {
            $content .= "§6§l  ★ RANK MÁXIMO ALCANÇADO! ★\n";
        }

        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";

        $form->setTitle("§l§b👤 MEU PERFIL");
        $form->setContent($content);
        $form->setButton1("§7← Voltar");
        $form->setButton2("§7Fechar");

        $player->sendForm($form);
    }

    public function openAdminUI(Player $player): void {
        $form = new SimpleForm(function(Player $player, ?int $data): void {
            if ($data === null) return;
            switch ($data) {
                case 0:
                    $this->openAdminSetRankUI($player);
                    break;
                case 1:
                    $this->openAdminResetUI($player);
                    break;
                case 2:
                    $this->openAdminAddMoneyUI($player);
                    break;
            }
        });

        $form->setTitle("§l§c⚙ ADMIN - RANKUP PRO");
        
        $content = "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§7  Painel administrativo\n";
        $content .= "§7  Selecione uma ação:\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";
        $form->setContent($content);

        $form->addButton("§e§lDEFINIR RANK\n§r§7Alterar rank de um jogador", SimpleForm::IMAGE_TYPE_PATH, "textures/ui/icon_setting");
        $form->addButton("§c§lRESETAR JOGADOR\n§r§7Resetar dados completamente", SimpleForm::IMAGE_TYPE_PATH, "textures/ui/refresh_light");
        $form->addButton("§a§lADICIONAR DINHEIRO\n§r§7Dar coins a um jogador", SimpleForm::IMAGE_TYPE_PATH, "textures/ui/icon_best3");

        $player->sendForm($form);
    }

    public function openAdminSetRankUI(Player $player): void {
        $rankManager = $this->plugin->getRankManager();
        $rankIds = $rankManager->getRankIds();

        $form = new CustomForm(function(Player $player, ?array $data) use ($rankIds): void {
            if ($data === null) return;
            $targetName = $data[0] ?? "";
            $rankIndex = $data[1] ?? 0;
            $rankId = $rankIds[$rankIndex] ?? null;

            if (empty($targetName) || $rankId === null) {
                $player->sendMessage("§c✘ Dados inválidos!");
                return;
            }

            $target = $this->plugin->getServer()->getPlayerByPrefix($targetName);
            if ($target === null) {
                $player->sendMessage("§c✘ Jogador não encontrado ou offline!");
                return;
            }

            $this->plugin->getRankManager()->setPlayerRank($target, $rankId);
            $rank = $this->plugin->getRankManager()->getRank($rankId);
            $tag = $rank['tag'] ?? $rankId;
            $player->sendMessage("§a✔ Rank de §e{$target->getName()}§a definido para {$tag}§a!");
            $target->sendMessage("§a✔ Um admin definiu seu rank para {$tag}§a!");
            $this->plugin->getScoreboardManager()->updateScoreboard($target);
        });

        $form->setTitle("§l§e DEFINIR RANK");
        $form->addInput("§fNome do Jogador", "Ex: Steve");

        $rankLabels = [];
        foreach ($rankIds as $id) {
            $rank = $rankManager->getRank($id);
            $rankLabels[] = strip_tags($rank['display-name'] ?? $id);
        }
        $form->addDropdown("§fSelecionar Rank", $rankLabels);

        $player->sendForm($form);
    }

    public function openAdminResetUI(Player $player): void {
        $form = new CustomForm(function(Player $player, ?array $data): void {
            if ($data === null) return;
            $targetName = $data[0] ?? "";

            if (empty($targetName)) {
                $player->sendMessage("§c✘ Nome inválido!");
                return;
            }

            $target = $this->plugin->getServer()->getPlayerByPrefix($targetName);
            if ($target === null) {
                $player->sendMessage("§c✘ Jogador não encontrado ou offline!");
                return;
            }

            $this->plugin->getPlayerDataManager()->resetPlayer($target->getName());
            $firstRank = $this->plugin->getRankManager()->getFirstRank() ?? "Membro";
            $this->plugin->getRankManager()->applyPermissions($target, $firstRank);
            $player->sendMessage("§a✔ Rank de §e{$target->getName()}§a foi resetado!");
            $target->sendMessage("§c✘ Seu rank foi resetado por um administrador.");
            $this->plugin->getScoreboardManager()->updateScoreboard($target);
        });

        $form->setTitle("§l§c⚠ RESETAR JOGADOR");
        $form->addInput("§fNome do Jogador", "Ex: Steve");

        $player->sendForm($form);
    }

    public function openAdminAddMoneyUI(Player $player): void {
        $form = new CustomForm(function(Player $player, ?array $data): void {
            if ($data === null) return;
            $targetName = $data[0] ?? "";
            $amount = (float)($data[1] ?? 0);

            if (empty($targetName) || $amount <= 0) {
                $player->sendMessage("§c✘ Dados inválidos!");
                return;
            }

            $target = $this->plugin->getServer()->getPlayerByPrefix($targetName);
            if ($target === null) {
                $player->sendMessage("§c✘ Jogador não encontrado ou offline!");
                return;
            }

            $this->plugin->getEconomyManager()->addBalance($target, $amount);
            $formatted = $this->plugin->getEconomyManager()->formatMoney($amount);
            $player->sendMessage("§a✔ Adicionado §e{$formatted}§a para §e{$target->getName()}§a!");
            $target->sendMessage("§a✔ Você recebeu §e{$formatted}§a de um administrador!");
            $this->plugin->getScoreboardManager()->updateScoreboard($target);
        });

        $form->setTitle("§l§a💰 ADICIONAR DINHEIRO");
        $form->addInput("§fNome do Jogador", "Ex: Steve");
        $form->addInput("§fQuantidade", "Ex: 1000");

        $player->sendForm($form);
    }
}
