<?php

declare(strict_types=1);

namespace RankUpPro\listeners;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerChatEvent;
use RankUpPro\Main;

class PlayerListener implements Listener {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        
        // Aplicar permissões do rank
        $rankId = $this->plugin->getPlayerDataManager()->getPlayerRank($player->getName());
        $this->plugin->getRankManager()->applyPermissions($player, $rankId);
        
        // Atualizar scoreboard
        $this->plugin->getScoreboardManager()->updateScoreboard($player);
        
        // Dar dinheiro inicial se for primeira vez
        $startingMoney = (float)($this->plugin->getConfig()->get("economy")["starting-money"] ?? 0);
        if ($startingMoney > 0 && $this->plugin->getEconomyManager()->getBalance($player) == 0) {
            $this->plugin->getEconomyManager()->setBalance($player, $startingMoney);
        }
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        $this->plugin->getScoreboardManager()->removeScoreboard($player);
    }

    public function onChat(PlayerChatEvent $event): void {
        if (!$this->plugin->getConfig()->get("settings")["chat-tag"]) {
            return;
        }

        $player = $event->getPlayer();
        $rankId = $this->plugin->getPlayerDataManager()->getPlayerRank($player->getName());
        $rank = $this->plugin->getRankManager()->getRank($rankId);
        
        if ($rank === null) return;

        $tag = $rank["tag"] ?? "§7[{$rankId}]";
        $chatColor = $rank["chat-color"] ?? "§f";
        $format = $this->plugin->getConfig()->get("settings")["chat-format"] ?? "{tag} §7{player}§r§7: {message}";
        
        $message = str_replace(
            ["{tag}", "{player}", "{message}", "{chat-color}"],
            [$tag, $player->getName(), $event->getMessage(), $chatColor],
            $format
        );
        
        $event->setFormat($message);
    }
}
