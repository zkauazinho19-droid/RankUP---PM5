<?php

declare(strict_types=1);

namespace RankUpPro\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use RankUpPro\Main;

class RankAdminCommand extends Command {

    private Main $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("rankadmin", "Admin de ranks", "/rankadmin");
        $this->setPermission("rankuppro.admin");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cApenas jogadores podem usar este comando!");
            return false;
        }

        if (!$sender->hasPermission("rankuppro.admin")) {
            $sender->sendMessage("§cVocê não tem permissão!");
            return false;
        }

        $ui = new \RankUpPro\ui\RankUI($this->plugin);
        $ui->openAdminUI($sender);
        return true;
    }
}
