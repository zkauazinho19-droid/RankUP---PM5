<?php

declare(strict_types=1);

namespace RankUpPro\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use RankUpPro\Main;

class RankUpCommand extends Command {

    private Main $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("rankup", "Subir de rank", "/rankup");
        $this->setPermission("rankuppro.use");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cApenas jogadores podem usar este comando!");
            return false;
        }

        $ui = new \RankUpPro\ui\RankUI($this->plugin);
        $ui->openMainUI($sender);
        return true;
    }
}
