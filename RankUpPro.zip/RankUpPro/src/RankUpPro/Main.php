<?php

declare(strict_types=1);

namespace RankUpPro;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use RankUpPro\commands\RankUpCommand;
use RankUpPro\commands\RankCommand;
use RankUpPro\commands\RanksCommand;
use RankUpPro\commands\RankAdminCommand;
use RankUpPro\managers\RankManager;
use RankUpPro\managers\EconomyManager;
use RankUpPro\managers\PlayerDataManager;
use RankUpPro\managers\ScoreboardManager;
use RankUpPro\managers\RewardManager;
use RankUpPro\listeners\PlayerListener;
use RankUpPro\tasks\SaveDataTask;
use RankUpPro\tasks\ScoreboardUpdateTask;

class Main extends PluginBase {

    private static Main $instance;
    private RankManager $rankManager;
    private EconomyManager $economyManager;
    private PlayerDataManager $playerDataManager;
    private ScoreboardManager $scoreboardManager;
    private RewardManager $rewardManager;

    public static function getInstance(): Main {
        return self::$instance;
    }

    protected function onLoad(): void {
        self::$instance = $this;
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        
        // Inicializar managers
        $this->playerDataManager = new PlayerDataManager($this);
        $this->rankManager = new RankManager($this);
        $this->economyManager = new EconomyManager($this);
        $this->scoreboardManager = new ScoreboardManager($this);
        $this->rewardManager = new RewardManager($this);
        
        // Registrar eventos
        $this->getServer()->getPluginManager()->registerEvents(new PlayerListener($this), $this);
        
        // Registrar comandos
        $this->getServer()->getCommandMap()->register("rankuppro", new RankUpCommand($this));
        $this->getServer()->getCommandMap()->register("rankuppro", new RankCommand($this));
        $this->getServer()->getCommandMap()->register("rankuppro", new RanksCommand($this));
        $this->getServer()->getCommandMap()->register("rankuppro", new RankAdminCommand($this));
        
        // Tasks
        $saveInterval = (int)($this->getConfig()->get("settings")["save-interval"] ?? 5);
        $this->getScheduler()->scheduleRepeatingTask(
            new SaveDataTask($this),
            $saveInterval * 60 * 20
        );
        
        if ($this->getConfig()->get("settings")["scoreboard"] ?? true) {
            $interval = (int)($this->getConfig()->get("settings")["scoreboard-update-interval"] ?? 20);
            $this->getScheduler()->scheduleRepeatingTask(
                new ScoreboardUpdateTask($this),
                $interval
            );
        }
        
        $this->getLogger()->info("§aRankUpPro v2.0.0 ativado! §7Minecraft 1.21.60");
    }

    protected function onDisable(): void {
        if (isset($this->playerDataManager)) {
            $this->playerDataManager->saveAll();
        }
        $this->getLogger()->info("§cRankUpPro desativado.");
    }

    public function getRankManager(): RankManager {
        return $this->rankManager;
    }

    public function getEconomyManager(): EconomyManager {
        return $this->economyManager;
    }

    public function getPlayerDataManager(): PlayerDataManager {
        return $this->playerDataManager;
    }

    public function getScoreboardManager(): ScoreboardManager {
        return $this->scoreboardManager;
    }

    public function getRewardManager(): RewardManager {
        return $this->rewardManager;
    }
}
