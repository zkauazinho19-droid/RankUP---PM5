<?php

declare(strict_types=1);

namespace RankUpPro\tasks;

use pocketmine\scheduler\Task;
use RankUpPro\Main;

class SaveDataTask extends Task {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun(): void {
        $this->plugin->getPlayerDataManager()->saveAll();
    }
}
