<?php

declare(strict_types=1);

namespace RankUpPro\tasks;

use pocketmine\scheduler\Task;
use RankUpPro\Main;

class ScoreboardUpdateTask extends Task {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun(): void {
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            $this->plugin->getScoreboardManager()->updateScoreboard($player);
        }
    }
}
