<?php

declare(strict_types=1);

namespace RankUpPro\managers;

use pocketmine\player\Player;
use pocketmine\network\mcpe\protocol\RemoveObjectivePacket;
use pocketmine\network\mcpe\protocol\SetDisplayObjectivePacket;
use pocketmine\network\mcpe\protocol\SetScorePacket;
use pocketmine\network\mcpe\protocol\types\ScorePacketEntry;
use RankUpPro\Main;

class ScoreboardManager {

    private Main $plugin;
    private array $scoreboards = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function updateScoreboard(Player $player): void {
        if (!$this->plugin->getConfig()->get("settings")["scoreboard"]) {
            return;
        }

        $this->removeScoreboard($player);
        $this->createScoreboard($player);
    }

    private function createScoreboard(Player $player): void {
        $title = $this->plugin->getConfig()->get("settings")["scoreboard-title"] ?? "§l§bRankUpPro";
        
        $pk = new SetDisplayObjectivePacket();
        $pk->displaySlot = "sidebar";
        $pk->objectiveName = "rankup";
        $pk->displayName = $title;
        $pk->criteriaName = "dummy";
        $pk->sortOrder = 0;
        $player->getNetworkSession()->sendDataPacket($pk);

        $lines = $this->getScoreboardLines($player);
        $this->sendLines($player, $lines);
        
        $this->scoreboards[$player->getName()] = true;
    }

    private function getScoreboardLines(Player $player): array {
        $dataManager = $this->plugin->getPlayerDataManager();
        $rankManager = $this->plugin->getRankManager();
        $econManager = $this->plugin->getEconomyManager();

        $rankId = $dataManager->getPlayerRank($player->getName());
        $rank = $rankManager->getRank($rankId);
        $balance = $econManager->getBalance($player);
        $nextRankId = $rankManager->getNextRank($rankId);

        $lines = [];
        $lines[] = "§7§m                    ";
        $lines[] = "§fRank: " . ($rank["scoreboard-color"] ?? "§7") . ($rank["display-name"] ?? $rankId);
        $lines[] = "§f{$econManager->getCurrencyName()}: §a" . $econManager->formatMoney($balance);
        $lines[] = " ";

        if ($nextRankId !== null) {
            $nextRank = $rankManager->getRank($nextRankId);
            $nextPrice = (float)($nextRank["price"] ?? 0);
            $lines[] = "§fPróximo: " . ($nextRank["scoreboard-color"] ?? "§7") . ($nextRank["display-name"] ?? $nextRankId);
            $lines[] = "§fPreço: §e" . $econManager->formatMoney($nextPrice);
        } else {
            $lines[] = "§6§lRANK MÁXIMO!";
        }

        $lines[] = "§7§m                    ";

        return $lines;
    }

    private function sendLines(Player $player, array $lines): void {
        $pk = new SetScorePacket();
        $pk->entries = [];
        
        foreach ($lines as $i => $line) {
            $entry = new ScorePacketEntry();
            $entry->objectiveName = "rankup";
            $entry->type = ScorePacketEntry::TYPE_FAKE_PLAYER;
            $entry->customName = $line;
            $entry->score = count($lines) - $i;
            $entry->scoreboardId = $i;
            $pk->entries[] = $entry;
        }
        
        $pk->type = SetScorePacket::TYPE_CHANGE;
        $player->getNetworkSession()->sendDataPacket($pk);
    }

    public function removeScoreboard(Player $player): void {
        if (!isset($this->scoreboards[$player->getName()])) {
            return;
        }

        $pk = new RemoveObjectivePacket();
        $pk->objectiveName = "rankup";
        $player->getNetworkSession()->sendDataPacket($pk);
        
        unset($this->scoreboards[$player->getName()]);
    }
}
