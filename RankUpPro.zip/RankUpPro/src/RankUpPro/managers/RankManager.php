<?php

declare(strict_types=1);

namespace RankUpPro\managers;

use pocketmine\player\Player;
use RankUpPro\Main;

class RankManager {

    private Main $plugin;
    private array $ranks = [];
    private array $rankOrder = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->loadRanks();
    }

    private function loadRanks(): void {
        $ranksConfig = $this->plugin->getConfig()->get("ranks", []);
        foreach ($ranksConfig as $rankId => $rankData) {
            $this->ranks[$rankId] = $rankData;
            $order = (int)($rankData["order"] ?? 999);
            $this->rankOrder[$order] = $rankId;
        }
        ksort($this->rankOrder);
    }

    public function getRank(string $rankId): ?array {
        return $this->ranks[$rankId] ?? null;
    }

    public function getRanks(): array {
        return $this->ranks;
    }

    public function getRankIds(): array {
        return array_values($this->rankOrder);
    }

    public function getFirstRank(): string {
        return reset($this->rankOrder) ?: "Membro";
    }

    public function getNextRank(string $currentRank): ?string {
        $rankIds = $this->getRankIds();
        $currentIndex = array_search($currentRank, $rankIds);
        if ($currentIndex === false) return null;
        return $rankIds[$currentIndex + 1] ?? null;
    }

    public function getRankIndex(string $rankId): int {
        $rankIds = $this->getRankIds();
        $index = array_search($rankId, $rankIds);
        return $index !== false ? $index : 0;
    }

    public function getTotalRanks(): int {
        return count($this->ranks);
    }

    public function setPlayerRank(Player $player, string $rankId): void {
        $this->plugin->getPlayerDataManager()->setPlayerRank($player->getName(), $rankId);
        $this->applyPermissions($player, $rankId);
        $this->plugin->getRewardManager()->giveRankRewards($player, $rankId);
    }

    public function applyPermissions(Player $player, string $rankId): void {
        $rank = $this->getRank($rankId);
        if ($rank === null) return;
        
        $permissions = $rank["permissions"] ?? [];
        foreach ($permissions as $perm) {
            $player->addAttachment($this->plugin, $perm, true);
        }
    }

    public function executeRankupCommands(Player $player, string $rankId): void {
        $rank = $this->getRank($rankId);
        if ($rank === null) return;
        
        $commands = $rank["commands-on-rankup"] ?? [];
        foreach ($commands as $cmd) {
            $cmd = str_replace("{player}", $player->getName(), $cmd);
            $this->plugin->getServer()->dispatchCommand($this->plugin->getServer()->getCommandMap()->getCommand("say") ? $this->plugin->getServer() : $player, $cmd);
        }
    }

    public function getProgressBar(string $rankId): string {
        $currentIndex = $this->getRankIndex($rankId);
        $total = $this->getTotalRanks();
        $percentage = $total > 0 ? ($currentIndex / $total) * 100 : 0;
        
        $filled = (int)(($percentage / 100) * 20);
        $empty = 20 - $filled;
        
        return "§a" . str_repeat("█", $filled) . "§7" . str_repeat("█", $empty);
    }
}
