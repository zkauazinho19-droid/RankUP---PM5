<?php

declare(strict_types=1);

namespace RankUpPro\managers;

use pocketmine\utils\Config;
use RankUpPro\Main;

class PlayerDataManager {

    private Main $plugin;
    private Config $data;
    private array $cache = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->data = new Config($plugin->getDataFolder() . "players.json", Config::JSON);
        $this->cache = $this->data->getAll();
    }

    public function getPlayerRank(string $playerName): string {
        return $this->cache[$playerName]["rank"] ?? $this->plugin->getRankManager()->getFirstRank();
    }

    public function setPlayerRank(string $playerName, string $rank): void {
        if (!isset($this->cache[$playerName])) {
            $this->cache[$playerName] = [];
        }
        $this->cache[$playerName]["rank"] = $rank;
        $this->cache[$playerName]["total_rankups"] = ($this->cache[$playerName]["total_rankups"] ?? 0) + 1;
    }

    public function getTotalRankups(string $playerName): int {
        return $this->cache[$playerName]["total_rankups"] ?? 0;
    }

    public function resetPlayer(string $playerName): void {
        $firstRank = $this->plugin->getRankManager()->getFirstRank();
        $this->cache[$playerName] = [
            "rank" => $firstRank,
            "total_rankups" => 0
        ];
    }

    public function saveAll(): void {
        $this->data->setAll($this->cache);
        $this->data->save();
    }
}
