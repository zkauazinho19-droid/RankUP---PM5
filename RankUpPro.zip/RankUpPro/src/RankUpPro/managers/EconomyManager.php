<?php

declare(strict_types=1);

namespace RankUpPro\managers;

use pocketmine\player\Player;
use pocketmine\utils\Config;
use RankUpPro\Main;

class EconomyManager {

    private Main $plugin;
    private string $provider;
    private Config $balances;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->provider = $plugin->getConfig()->get("economy")["provider"] ?? "internal";
        $this->balances = new Config($plugin->getDataFolder() . "balances.json", Config::JSON);
    }

    public function getBalance(Player $player): float {
        if ($this->provider === "economyapi") {
            $economyAPI = $this->plugin->getServer()->getPluginManager()->getPlugin("EconomyAPI");
            if ($economyAPI !== null) {
                return (float)$economyAPI->myMoney($player);
            }
        }
        
        return (float)($this->balances->get($player->getName(), 0));
    }

    public function addBalance(Player $player, float $amount): void {
        if ($this->provider === "economyapi") {
            $economyAPI = $this->plugin->getServer()->getPluginManager()->getPlugin("EconomyAPI");
            if ($economyAPI !== null) {
                $economyAPI->addMoney($player, $amount);
                return;
            }
        }
        
        $current = $this->getBalance($player);
        $this->setBalance($player, $current + $amount);
    }

    public function removeBalance(Player $player, float $amount): void {
        if ($this->provider === "economyapi") {
            $economyAPI = $this->plugin->getServer()->getPluginManager()->getPlugin("EconomyAPI");
            if ($economyAPI !== null) {
                $economyAPI->reduceMoney($player, $amount);
                return;
            }
        }
        
        $current = $this->getBalance($player);
        $this->setBalance($player, max(0, $current - $amount));
    }

    public function setBalance(Player $player, float $amount): void {
        if ($this->provider === "economyapi") {
            $economyAPI = $this->plugin->getServer()->getPluginManager()->getPlugin("EconomyAPI");
            if ($economyAPI !== null) {
                $economyAPI->setMoney($player, $amount);
                return;
            }
        }
        
        $this->balances->set($player->getName(), $amount);
        $this->balances->save();
    }

    public function formatMoney(float $amount): string {
        $symbol = $this->plugin->getConfig()->get("economy")["currency-symbol"] ?? "$";
        return $symbol . number_format($amount, 0, ',', '.');
    }

    public function getCurrencyName(): string {
        return $this->plugin->getConfig()->get("economy")["currency-name"] ?? "Coins";
    }
}
