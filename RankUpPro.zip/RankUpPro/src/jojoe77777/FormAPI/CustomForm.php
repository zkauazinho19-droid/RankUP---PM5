<?php

declare(strict_types=1);

namespace jojoe77777\FormAPI;

class CustomForm extends Form {

    private array $labelMap = [];
    private array $validationMethods = [];

    public function __construct(?callable $callable) {
        parent::__construct($callable);
        $this->data["type"] = "custom_form";
        $this->data["title"] = "";
        $this->data["content"] = [];
    }

    public function processData(&$data): void {
        if ($data !== null && is_array($data)) {
            $new = [];
            foreach ($data as $i => $v) {
                $new[$this->labelMap[$i]] = $v;
            }
            $data = $new;
        }
    }

    public function setTitle(string $title): void {
        $this->data["title"] = $title;
    }

    public function getTitle(): string {
        return $this->data["title"];
    }

    public function addLabel(string $text, ?string $label = null): void {
        $this->addContent(["type" => "label", "text" => $text]);
        $this->labelMap[] = $label ?? count($this->labelMap);
    }

    public function addToggle(string $text, bool $default = false, ?string $label = null): void {
        $this->addContent(["type" => "toggle", "text" => $text, "default" => $default]);
        $this->labelMap[] = $label ?? count($this->labelMap);
    }

    public function addSlider(string $text, int $min, int $max, int $step = -1, int $default = -1, ?string $label = null): void {
        $content = ["type" => "slider", "text" => $text, "min" => $min, "max" => $max];
        if ($step !== -1) $content["step"] = $step;
        if ($default !== -1) $content["default"] = $default;
        $this->addContent($content);
        $this->labelMap[] = $label ?? count($this->labelMap);
    }

    public function addStepSlider(string $text, array $steps, int $default = 0, ?string $label = null): void {
        $this->addContent(["type" => "step_slider", "text" => $text, "steps" => $steps, "default" => $default]);
        $this->labelMap[] = $label ?? count($this->labelMap);
    }

    public function addDropdown(string $text, array $options, int $default = 0, ?string $label = null): void {
        $this->addContent(["type" => "dropdown", "text" => $text, "options" => $options, "default" => $default]);
        $this->labelMap[] = $label ?? count($this->labelMap);
    }

    public function addInput(string $text, string $placeholder = "", string $default = "", ?string $label = null): void {
        $this->addContent(["type" => "input", "text" => $text, "placeholder" => $placeholder, "default" => $default]);
        $this->labelMap[] = $label ?? count($this->labelMap);
    }

    private function addContent(array $content): void {
        $this->data["content"][] = $content;
    }
}
