<?php

declare(strict_types=1);

namespace jojoe77777\FormAPI;

class SimpleForm extends Form {

    const IMAGE_TYPE_PATH = 0;
    const IMAGE_TYPE_URL = 1;

    private array $labelMap = [];

    public function __construct(?callable $callable) {
        parent::__construct($callable);
        $this->data["type"] = "form";
        $this->data["title"] = "";
        $this->data["content"] = "";
        $this->data["buttons"] = [];
    }

    public function processData(&$data): void {
        if ($data !== null && isset($this->labelMap[$data])) {
            $data = $this->labelMap[$data];
        }
    }

    public function setTitle(string $title): void {
        $this->data["title"] = $title;
    }

    public function setContent(string $content): void {
        $this->data["content"] = $content;
    }

    public function addButton(string $text, int $imageType = -1, string $imagePath = "", ?string $label = null): void {
        $content = ["text" => $text];
        if ($imageType !== -1) {
            $content["image"]["type"] = $imageType === 0 ? "path" : "url";
            $content["image"]["data"] = $imagePath;
        }
        if ($label === null) {
            $label = count($this->labelMap);
        }
        $this->labelMap[] = $label;
        $this->data["buttons"][] = $content;
    }
}
