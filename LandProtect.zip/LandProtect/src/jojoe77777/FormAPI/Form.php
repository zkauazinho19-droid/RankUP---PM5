<?php

declare(strict_types=1);

namespace jojoe77777\FormAPI;

use pocketmine\form\Form as IForm;
use pocketmine\player\Player;

abstract class Form implements IForm {

    protected array $data = [];
    private $callable;

    public function __construct(?callable $callable) {
        $this->callable = $callable;
    }

    public function handleResponse(Player $player, $data): void {
        $this->processData($data);
        if ($this->callable !== null) {
            ($this->callable)($player, $data);
        }
    }

    public function processData(&$data): void {}

    public function jsonSerialize(): array {
        return $this->data;
    }
}
