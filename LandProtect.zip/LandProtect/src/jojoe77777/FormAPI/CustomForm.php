<?php

declare(strict_types=1);

namespace jojoe77777\FormAPI;

class CustomForm extends Form {

    private array $labelMap = [];

    public function __construct(?callable $callable) {
        parent::__construct($callable);
        $this->data["type"] = "custom_form";
        $this->data["title"] = "";
        $this->data["content"] = [];
    }

    public function processData(&$data): void {
        if ($data !== null && is_array($data)) {
            $new = [];
            foreach ($data as $i => $v) {
                $new[$this->labelMap[$i]] = $v;
            }
            $data = $new;
        }
    }

    public function setTitle(string $title): void {
        $this->data["title"] = $title;
    }

    public function addInput(string $text, string $placeholder = "", string $default = "", ?string $label = null): void {
        $this->addContent(["type" => "input", "text" => $text, "placeholder" => $placeholder, "default" => $default]);
        $this->labelMap[] = $label ?? count($this->labelMap);
    }

    public function addDropdown(string $text, array $options, int $default = 0, ?string $label = null): void {
        $this->addContent(["type" => "dropdown", "text" => $text, "options" => $options, "default" => $default]);
        $this->labelMap[] = $label ?? count($this->labelMap);
    }

    private function addContent(array $content): void {
        $this->data["content"][] = $content;
    }
}
