<?php

declare(strict_types=1);

namespace jojoe77777\FormAPI;

class ModalForm extends Form {

    public function __construct(?callable $callable) {
        parent::__construct($callable);
        $this->data["type"] = "modal";
        $this->data["title"] = "";
        $this->data["content"] = "";
        $this->data["button1"] = "";
        $this->data["button2"] = "";
    }

    public function processData(&$data): void {
        $data = $data !== null;
    }

    public function setTitle(string $title): void {
        $this->data["title"] = $title;
    }

    public function setContent(string $content): void {
        $this->data["content"] = $content;
    }

    public function setButton1(string $text): void {
        $this->data["button1"] = $text;
    }

    public function setButton2(string $text): void {
        $this->data["button2"] = $text;
    }
}
