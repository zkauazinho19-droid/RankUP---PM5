<?php

declare(strict_types=1);

namespace LandProtect\managers;

use pocketmine\player\Player;
use LandProtect\Main;

class EconomyManager {

    private Main $plugin;
    private string $provider;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->provider = $plugin->getConfig()->get("economy")["provider"] ?? "rankuppro";
    }

    public function hasMoney(Player $player, float $amount): bool {
        return $this->getBalance($player) >= $amount;
    }

    public function takeMoney(Player $player, float $amount): bool {
        if (!$this->hasMoney($player, $amount)) {
            return false;
        }
        
        $balance = $this->getBalance($player);
        $this->setBalance($player, $balance - $amount);
        return true;
    }

    public function getBalance(Player $player): float {
        if ($this->provider === "rankuppro") {
            return $this->getRankUpProBalance($player);
        } elseif ($this->provider === "economyapi") {
            return $this->getEconomyAPIBalance($player);
        }
        return 0.0;
    }

    public function setBalance(Player $player, float $amount): void {
        if ($this->provider === "rankuppro") {
            $this->setRankUpProBalance($player, $amount);
        } elseif ($this->provider === "economyapi") {
            $this->setEconomyAPIBalance($player, $amount);
        }
    }

    private function getRankUpProBalance(Player $player): float {
        $rankUpPro = $this->plugin->getServer()->getPluginManager()->getPlugin("RankUpPro");
        if ($rankUpPro === null) return 0.0;
        
        // @phpstan-ignore-next-line
        $economyManager = $rankUpPro->getEconomyManager();
        if ($economyManager === null) return 0.0;
        
        // @phpstan-ignore-next-line
        return (float)$economyManager->getBalance($player);
    }

    private function setRankUpProBalance(Player $player, float $amount): void {
        $rankUpPro = $this->plugin->getServer()->getPluginManager()->getPlugin("RankUpPro");
        if ($rankUpPro === null) return;
        
        // @phpstan-ignore-next-line
        $economyManager = $rankUpPro->getEconomyManager();
        if ($economyManager === null) return;
        
        // @phpstan-ignore-next-line
        $economyManager->setBalance($player, $amount);
    }

    private function getEconomyAPIBalance(Player $player): float {
        $economyAPI = $this->plugin->getServer()->getPluginManager()->getPlugin("EconomyAPI");
        if ($economyAPI === null) return 0.0;
        
        // @phpstan-ignore-next-line
        return (float)$economyAPI->myMoney($player);
    }

    private function setEconomyAPIBalance(Player $player, float $amount): void {
        $economyAPI = $this->plugin->getServer()->getPluginManager()->getPlugin("EconomyAPI");
        if ($economyAPI === null) return;
        
        // @phpstan-ignore-next-line
        $economyAPI->setMoney($player, $amount);
    }

    public function formatMoney(float $amount): string {
        $symbol = $this->plugin->getConfig()->get("economy")["currency-symbol"] ?? "$";
        return $symbol . number_format($amount, 0, ',', '.');
    }

    public function getCurrencyName(): string {
        return $this->plugin->getConfig()->get("economy")["currency-name"] ?? "Coins";
    }
}
