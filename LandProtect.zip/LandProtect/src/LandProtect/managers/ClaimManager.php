<?php

declare(strict_types=1);

namespace LandProtect\managers;

use pocketmine\player\Player;
use pocketmine\world\Position;
use pocketmine\utils\Config;
use LandProtect\Main;
use LandProtect\models\Claim;

class ClaimManager {

    private Main $plugin;
    private Config $dataConfig;
    private array $claims = [];
    private array $cooldowns = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->dataConfig = new Config(
            $plugin->getDataFolder() . "claims.json",
            Config::JSON
        );
        $this->loadClaims();
    }

    private function loadClaims(): void {
        $data = $this->dataConfig->getAll();
        foreach ($data as $owner => $claimsData) {
            $this->claims[$owner] = [];
            foreach ($claimsData as $claimData) {
                $this->claims[$owner][] = Claim::fromArray($claimData);
            }
        }
    }

    public function createClaim(Player $player, Position $pos): bool {
        $playerName = $player->getName();
        
        // Verificar se já tem terreno (apenas 1 por jogador)
        if (isset($this->claims[$playerName]) && !empty($this->claims[$playerName])) {
            $player->sendMessage($this->plugin->getPrefix() . "§cVocê já tem um terreno! Use /proteger para gerenciá-lo.");
            return false;
        }
        
        // Verificar cooldown
        if (isset($this->cooldowns[$playerName])) {
            $remaining = $this->cooldowns[$playerName] - time();
            if ($remaining > 0) {
                $player->sendMessage($this->plugin->getPrefix() . "§cAguarde {$remaining}s para criar um terreno!");
                return false;
            }
        }
        
        // Obter tamanho baseado no rank (tamanho inicial 16x16)
        $size = $this->plugin->getRankManager()->getLandSize($player);
        
        // Criar claim
        $claim = new Claim(
            $playerName,
            $pos->getWorld()->getFolderName(),
            (int)$pos->getX(),
            (int)$pos->getZ(),
            $size
        );
        
        // Verificar sobreposição
        if ($this->hasOverlap($claim)) {
            $player->sendMessage($this->plugin->getMessage("claim-overlap"));
            return false;
        }
        
        // Verificar distância mínima
        $minDistance = $this->plugin->getConfig()->get("advanced")["min-distance-between-claims"] ?? 10;
        if (!$this->checkMinDistance($claim, $minDistance)) {
            $player->sendMessage($this->plugin->getMessage("claim-too-close", ["distance" => $minDistance]));
            return false;
        }
        
        // Adicionar claim
        $this->claims[$playerName] = [$claim];
        
        // Cooldown
        $cooldown = $this->plugin->getConfig()->get("advanced")["claim-cooldown"] ?? 60;
        $this->cooldowns[$playerName] = time() + $cooldown;
        
        $player->sendMessage($this->plugin->getMessage("claim-created", ["size" => $size]));
        return true;
    }

    // Método para aumentar terreno automaticamente (GRÁTIS ao upar de rank)
    public function upgradeClaimSize(Player $player): bool {
        $playerName = $player->getName();
        
        if (!isset($this->claims[$playerName]) || empty($this->claims[$playerName])) {
            $player->sendMessage($this->plugin->getPrefix() . "§cVocê não tem um terreno!");
            return false;
        }
        
        $claim = $this->claims[$playerName][0];
        $currentSize = $claim->getSize();
        $maxSize = $this->plugin->getRankManager()->getLandSize($player);
        
        if ($currentSize >= $maxSize) {
            $player->sendMessage($this->plugin->getPrefix() . "§cSeu terreno já está no tamanho máximo do seu rank!");
            $player->sendMessage($this->plugin->getPrefix() . "§eUpe de rank para aumentar mais!");
            return false;
        }
        
        // Expandir automaticamente para o tamanho do rank (GRÁTIS!)
        $claim->setSize($maxSize);
        
        $player->sendMessage($this->plugin->getMessage("claim-expanded", ["size" => $maxSize]));
        $player->sendMessage($this->plugin->getPrefix() . "§a✔ Terreno atualizado para o tamanho do seu rank!");
        
        // Efeito visual
        $player->getWorld()->addSound($player->getPosition(), new \pocketmine\world\sound\XpLevelUpSound());
        
        return true;
    }

    public function getPlayerClaim(string $playerName): ?Claim {
        if (isset($this->claims[$playerName]) && !empty($this->claims[$playerName])) {
            return $this->claims[$playerName][0];
        }
        return null;
    }

    public function deleteClaim(Player $player, Claim $claim): bool {
        $playerName = $player->getName();
        
        if (!isset($this->claims[$playerName])) {
            return false;
        }
        
        $key = array_search($claim, $this->claims[$playerName], true);
        if ($key === false) {
            return false;
        }
        
        unset($this->claims[$playerName][$key]);
        $this->claims[$playerName] = array_values($this->claims[$playerName]);
        
        if (empty($this->claims[$playerName])) {
            unset($this->claims[$playerName]);
        }
        
        $player->sendMessage($this->plugin->getMessage("claim-deleted"));
        return true;
    }

    public function getClaimAt(Position $pos): ?Claim {
        $world = $pos->getWorld()->getFolderName();
        $x = (int)$pos->getX();
        $z = (int)$pos->getZ();
        
        foreach ($this->claims as $claims) {
            foreach ($claims as $claim) {
                if ($claim->getWorld() === $world && $claim->isInside($x, $z)) {
                    return $claim;
                }
            }
        }
        
        return null;
    }

    public function getPlayerClaims(string $playerName): array {
        return $this->claims[$playerName] ?? [];
    }

    public function getAllClaims(): array {
        $all = [];
        foreach ($this->claims as $claims) {
            $all = array_merge($all, $claims);
        }
        return $all;
    }

    private function hasOverlap(Claim $claim, ?Claim $ignore = null): bool {
        foreach ($this->claims as $claims) {
            foreach ($claims as $existingClaim) {
                if ($ignore !== null && $existingClaim === $ignore) {
                    continue;
                }
                if ($claim->overlaps($existingClaim)) {
                    return true;
                }
            }
        }
        return false;
    }

    private function checkMinDistance(Claim $claim, int $minDistance): bool {
        foreach ($this->claims as $claims) {
            foreach ($claims as $existingClaim) {
                if ($claim->getWorld() !== $existingClaim->getWorld()) {
                    continue;
                }
                $distance = $claim->distanceTo($existingClaim);
                if ($distance < $minDistance) {
                    return false;
                }
            }
        }
        return true;
    }

    public function saveAll(): void {
        $data = [];
        foreach ($this->claims as $owner => $claims) {
            $data[$owner] = [];
            foreach ($claims as $claim) {
                $data[$owner][] = $claim->toArray();
            }
        }
        $this->dataConfig->setAll($data);
        $this->dataConfig->save();
    }
}
