<?php

declare(strict_types=1);

namespace LandProtect\managers;

use pocketmine\player\Player;
use LandProtect\Main;

class RankManager {

    private Main $plugin;
    private bool $rankUpProEnabled = false;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        
        // Verificar se RankUpPro está instalado
        $rankUpPro = $plugin->getServer()->getPluginManager()->getPlugin("RankUpPro");
        if ($rankUpPro !== null && $rankUpPro->isEnabled()) {
            $this->rankUpProEnabled = true;
            $plugin->getLogger()->info("§aRankUpPro detectado! Integração ativa.");
        }
    }

    public function getPlayerRank(Player $player): string {
        if (!$this->rankUpProEnabled) {
            return "default";
        }
        
        // Integração com RankUpPro
        $rankUpPro = $this->plugin->getServer()->getPluginManager()->getPlugin("RankUpPro");
        if ($rankUpPro === null) {
            return "default";
        }
        
        // @phpstan-ignore-next-line
        $dataManager = $rankUpPro->getPlayerDataManager();
        if ($dataManager === null) {
            return "default";
        }
        
        // @phpstan-ignore-next-line
        return $dataManager->getPlayerRank($player->getName()) ?? "default";
    }

    // Retorna o tamanho do terreno baseado no rank
    public function getLandSize(Player $player): int {
        $rank = $this->getPlayerRank($player);
        $config = $this->plugin->getConfig()->get("land-by-rank");
        
        if (isset($config[$rank])) {
            return (int)($config[$rank]["land-size"] ?? 16);
        }
        
        return (int)($config["default"]["land-size"] ?? 16);
    }

    public function isRankUpProEnabled(): bool {
        return $this->rankUpProEnabled;
    }

    public function getRankDisplayName(string $rankId): string {
        // Retornar nome formatado do rank
        return match($rankId) {
            "Madeira 1", "Madeira 2", "Madeira 3" => "§6" . $rankId,
            "Pedra 1", "Pedra 2", "Pedra 3" => "§7" . $rankId,
            "Ferro 1", "Ferro 2", "Ferro 3" => "§f" . $rankId,
            "Ouro 1", "Ouro 2", "Ouro 3" => "§e" . $rankId,
            "Diamante 1", "Diamante 2", "Diamante 3" => "§b" . $rankId,
            "Membro" => "§a" . $rankId,
            "Elite" => "§6§l" . $rankId,
            default => "§7" . $rankId
        };
    }
}
