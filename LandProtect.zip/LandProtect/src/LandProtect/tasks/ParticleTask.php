<?php

declare(strict_types=1);

namespace LandProtect\tasks;

use pocketmine\scheduler\Task;
use pocketmine\world\particle\HappyVillagerParticle;
use LandProtect\Main;

class ParticleTask extends Task {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun(): void {
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            $claim = $this->plugin->getClaimManager()->getPlayerClaim($player->getName());
            if ($claim === null) continue;

            $world = $this->plugin->getServer()->getWorldManager()->getWorldByName($claim->getWorld());
            if ($world === null) continue;

            $minX = $claim->getMinX();
            $maxX = $claim->getMaxX();
            $minZ = $claim->getMinZ();
            $maxZ = $claim->getMaxZ();
            $y = (int)$player->getPosition()->getY();

            // Mostrar partículas nas bordas
            for ($x = $minX; $x <= $maxX; $x += 4) {
                $world->addParticle($world->getBlock($x, $y, $minZ)->getPosition(), new HappyVillagerParticle());
                $world->addParticle($world->getBlock($x, $y, $maxZ)->getPosition(), new HappyVillagerParticle());
            }
            
            for ($z = $minZ; $z <= $maxZ; $z += 4) {
                $world->addParticle($world->getBlock($minX, $y, $z)->getPosition(), new HappyVillagerParticle());
                $world->addParticle($world->getBlock($maxX, $y, $z)->getPosition(), new HappyVillagerParticle());
            }
        }
    }
}
