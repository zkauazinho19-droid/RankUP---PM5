<?php

declare(strict_types=1);

namespace LandProtect\tasks;

use pocketmine\scheduler\Task;
use LandProtect\Main;

class SaveDataTask extends Task {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun(): void {
        $this->plugin->getClaimManager()->saveAll();
    }
}
