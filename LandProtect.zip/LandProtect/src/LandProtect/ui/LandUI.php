<?php

declare(strict_types=1);

namespace LandProtect\ui;

use pocketmine\player\Player;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use jojoe77777\FormAPI\ModalForm;
use LandProtect\Main;
use LandProtect\models\Claim;

class LandUI {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function openMainMenu(Player $player): void {
        $claim = $this->plugin->getClaimManager()->getPlayerClaim($player->getName());
        $rank = $this->plugin->getRankManager()->getPlayerRank($player);
        $rankDisplay = $this->plugin->getRankManager()->getRankDisplayName($rank);
        $maxSize = $this->plugin->getRankManager()->getLandSize($player);

        $form = new SimpleForm(function(Player $player, ?int $data) use ($claim): void {
            if ($data === null) return;
            switch ($data) {
                case 0:
                    if ($claim === null) {
                        $this->createClaim($player);
                    } else {
                        $this->upgradeClaimSize($player);
                    }
                    break;
                case 1:
                    if ($claim !== null) {
                        $this->openClaimManageMenu($player, $claim);
                    }
                    break;
                case 2:
                    $this->openInfoMenu($player);
                    break;
            }
        });

        $form->setTitle("§l§6🛡 §b§lPROTEGER TERRENO");

        $content = "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§f  Jogador: §b{$player->getName()}\n";
        $content .= "§f  Rank: {$rankDisplay}\n";
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        
        if ($claim === null) {
            $content .= "§f  Status: §cSem terreno\n";
            $content .= "§f  Tamanho disponível: §a{$maxSize}x{$maxSize}\n";
            $content .= "§f\n";
            $content .= "§7  Crie seu terreno na posição atual!\n";
        } else {
            $currentSize = $claim->getSize();
            $members = count($claim->getMembers());
            $canUpgrade = $currentSize < $maxSize;
            
            $content .= "§f  Tamanho atual: §a{$currentSize}x{$currentSize}\n";
            $content .= "§f  Tamanho máximo: §e{$maxSize}x{$maxSize}\n";
            $content .= "§f  Membros: §b{$members}\n";
            $content .= "§f\n";
            
            if ($canUpgrade) {
                $content .= "§a  ✔ Você pode aumentar seu terreno!\n";
                $content .= "§7  Expande automaticamente para {$maxSize}x{$maxSize}\n";
                $content .= "§7  §a§lGRÁTIS!§r§7 Basta upar de rank!\n";
            } else {
                $content .= "§e  ⚠ Terreno no tamanho máximo do rank\n";
                $content .= "§7  Upe de rank para aumentar mais!\n";
            }
        }
        
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";

        $form->setContent($content);

        if ($claim === null) {
            $form->addButton(
                "§a§l✚ CRIAR TERRENO\n§r§7Proteger área atual ({$maxSize}x{$maxSize})",
                SimpleForm::IMAGE_TYPE_PATH,
                "textures/ui/icon_new"
            );
        } else {
            $currentSize = $claim->getSize();
            $canUpgrade = $currentSize < $maxSize;
            $btnColor = $canUpgrade ? "§a§l" : "§7§l";
            $btnText = $canUpgrade ? "AUMENTAR TERRENO" : "TAMANHO MÁXIMO";
            $btnSub = $canUpgrade ? "§r§7Expandir para {$maxSize}x{$maxSize} (GRÁTIS)" : "§r§7Upe de rank para aumentar";
            
            $form->addButton(
                "{$btnColor}⬆ {$btnText}\n{$btnSub}",
                SimpleForm::IMAGE_TYPE_PATH,
                "textures/ui/upgrade_arrow"
            );
        }

        if ($claim !== null) {
            $form->addButton(
                "§e§l⚙ GERENCIAR TERRENO\n§r§7Membros e configurações",
                SimpleForm::IMAGE_TYPE_PATH,
                "textures/ui/icon_setting"
            );
        }

        $form->addButton(
            "§b§lℹ INFORMAÇÕES\n§r§7Ver detalhes do sistema",
            SimpleForm::IMAGE_TYPE_PATH,
            "textures/ui/book_writable"
        );

        $player->sendForm($form);
    }

    private function createClaim(Player $player): void {
        $result = $this->plugin->getClaimManager()->createClaim($player, $player->getPosition());
        
        if ($result) {
            $player->getWorld()->addSound($player->getPosition(), new \pocketmine\world\sound\XpLevelUpSound());
        }
        
        $this->openMainMenu($player);
    }

    private function upgradeClaimSize(Player $player): void {
        $result = $this->plugin->getClaimManager()->upgradeClaimSize($player);
        
        if ($result) {
            $player->getWorld()->addSound($player->getPosition(), new \pocketmine\world\sound\XpLevelUpSound());
        }
        
        $this->openMainMenu($player);
    }

    public function openClaimManageMenu(Player $player, Claim $claim): void {
        $form = new SimpleForm(function(Player $player, ?int $data) use ($claim): void {
            if ($data === null) {
                $this->openMainMenu($player);
                return;
            }
            switch ($data) {
                case 0:
                    $this->openMembersMenu($player, $claim);
                    break;
                case 1:
                    $this->openDeleteConfirm($player, $claim);
                    break;
                case 2:
                    $this->openMainMenu($player);
                    break;
            }
        });

        $size = $claim->getSize();
        $members = count($claim->getMembers());

        $form->setTitle("§l§6⚙ GERENCIAR TERRENO");

        $content = "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§f  Tamanho: §a{$size}x{$size}\n";
        $content .= "§f  Membros: §b{$members}\n";
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";

        $form->setContent($content);

        $form->addButton(
            "§b§l👥 GERENCIAR MEMBROS\n§r§7Adicionar/remover membros",
            SimpleForm::IMAGE_TYPE_PATH,
            "textures/ui/icon_steve"
        );

        $form->addButton(
            "§c§l✘ DELETAR TERRENO\n§r§7Remover proteção",
            SimpleForm::IMAGE_TYPE_PATH,
            "textures/ui/trash_default"
        );

        $form->addButton(
            "§7← Voltar",
            SimpleForm::IMAGE_TYPE_PATH,
            "textures/ui/arrow_left"
        );

        $player->sendForm($form);
    }

    public function openMembersMenu(Player $player, Claim $claim): void {
        $form = new SimpleForm(function(Player $player, ?int $data) use ($claim): void {
            if ($data === null) {
                $this->openClaimManageMenu($player, $claim);
                return;
            }
            if ($data === 0) {
                $this->openAddMemberForm($player, $claim);
            } elseif ($data === 1) {
                $this->openRemoveMemberMenu($player, $claim);
            } else {
                $this->openClaimManageMenu($player, $claim);
            }
        });

        $members = $claim->getMembers();
        $memberCount = count($members);

        $form->setTitle("§l§b👥 MEMBROS");

        $content = "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§f  Total de membros: §e{$memberCount}\n";
        $content .= "§f\n";
        
        if ($memberCount > 0) {
            $content .= "§7  Membros atuais:\n";
            foreach (array_slice($members, 0, 5) as $member) {
                $content .= "  §8• §f{$member}\n";
            }
            if ($memberCount > 5) {
                $content .= "  §7... e mais " . ($memberCount - 5) . " membros\n";
            }
        } else {
            $content .= "§7  Nenhum membro adicionado\n";
        }
        
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";

        $form->setContent($content);

        $form->addButton(
            "§a§l✚ ADICIONAR MEMBRO\n§r§7Permitir acesso",
            SimpleForm::IMAGE_TYPE_PATH,
            "textures/ui/icon_new"
        );

        $form->addButton(
            "§c§l✘ REMOVER MEMBRO\n§r§7Revogar acesso",
            SimpleForm::IMAGE_TYPE_PATH,
            "textures/ui/trash_default"
        );

        $form->addButton(
            "§7← Voltar",
            SimpleForm::IMAGE_TYPE_PATH,
            "textures/ui/arrow_left"
        );

        $player->sendForm($form);
    }

    public function openAddMemberForm(Player $player, Claim $claim): void {
        $form = new CustomForm(function(Player $player, ?array $data) use ($claim): void {
            if ($data === null) {
                $this->openMembersMenu($player, $claim);
                return;
            }
            
            $memberName = trim($data[0] ?? "");
            if (empty($memberName)) {
                $player->sendMessage($this->plugin->getPrefix() . "§cNome inválido!");
                $this->openMembersMenu($player, $claim);
                return;
            }
            
            if ($claim->isMember($memberName)) {
                $player->sendMessage($this->plugin->getMessage("already-member", ["player" => $memberName]));
            } else {
                $claim->addMember($memberName);
                $player->sendMessage($this->plugin->getMessage("member-added", ["player" => $memberName]));
            }
            
            $this->openMembersMenu($player, $claim);
        });

        $form->setTitle("§l§a✚ ADICIONAR MEMBRO");
        $form->addInput("§fNome do jogador:", "Ex: Steve");

        $player->sendForm($form);
    }

    public function openRemoveMemberMenu(Player $player, Claim $claim): void {
        $members = $claim->getMembers();
        
        if (empty($members)) {
            $player->sendMessage($this->plugin->getPrefix() . "§cNenhum membro para remover!");
            $this->openMembersMenu($player, $claim);
            return;
        }

        $form = new CustomForm(function(Player $player, ?array $data) use ($claim, $members): void {
            if ($data === null) {
                $this->openMembersMenu($player, $claim);
                return;
            }
            
            $index = $data[0] ?? 0;
            if (isset($members[$index])) {
                $memberName = $members[$index];
                $claim->removeMember($memberName);
                $player->sendMessage($this->plugin->getMessage("member-removed", ["player" => $memberName]));
            }
            
            $this->openMembersMenu($player, $claim);
        });

        $form->setTitle("§l§c✘ REMOVER MEMBRO");
        $form->addDropdown("§fSelecione o membro:", $members);

        $player->sendForm($form);
    }

    public function openDeleteConfirm(Player $player, Claim $claim): void {
        $form = new ModalForm(function(Player $player, ?bool $data) use ($claim): void {
            if ($data === null || !$data) {
                $this->openClaimManageMenu($player, $claim);
                return;
            }
            
            $this->plugin->getClaimManager()->deleteClaim($player, $claim);
            $this->openMainMenu($player);
        });

        $size = $claim->getSize();

        $form->setTitle("§l§c⚠ DELETAR TERRENO");

        $content = "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§c§lATENÇÃO!\n";
        $content .= "§r§f\n";
        $content .= "§7  Você está prestes a deletar\n";
        $content .= "§7  um terreno de §e{$size}x{$size}§7!\n";
        $content .= "§f\n";
        $content .= "§c  Esta ação é IRREVERSÍVEL!\n";
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";

        $form->setContent($content);
        $form->setButton1("§c§l✔ DELETAR");
        $form->setButton2("§a§l✘ CANCELAR");

        $player->sendForm($form);
    }

    public function openInfoMenu(Player $player): void {
        $rank = $this->plugin->getRankManager()->getPlayerRank($player);
        $rankDisplay = $this->plugin->getRankManager()->getRankDisplayName($rank);
        $landSize = $this->plugin->getRankManager()->getLandSize($player);

        $form = new ModalForm(function(Player $player, ?bool $data): void {
            $this->openMainMenu($player);
        });

        $form->setTitle("§l§bℹ INFORMAÇÕES");

        $content = "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§f\n";
        $content .= "§f  Seu rank: {$rankDisplay}\n";
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§e  Sistema de Terreno:\n";
        $content .= "§f\n";
        $content .= "§7  • 1 terreno por jogador\n";
        $content .= "§7  • Tamanho do seu rank: §a{$landSize}x{$landSize}\n";
        $content .= "§7  • Expansão automática ao upar\n";
        $content .= "§7  • Cada rank = +8x8 de terreno\n";
        $content .= "§7  • Totalmente GRÁTIS!\n";
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§b  Proteções ativas:\n";
        $content .= "§f\n";
        $content .= "§7  • §a✔ PVP ativo\n";
        $content .= "§7  • §c✘ Quebrar blocos\n";
        $content .= "§7  • §c✘ Colocar blocos\n";
        $content .= "§7  • §c✘ Matar mobs\n";
        $content .= "§7  • §c✘ Abrir baús\n";
        $content .= "§7  • §c✘ Pisotear plantações\n";
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n";
        $content .= "§r§e  Como funciona:\n";
        $content .= "§f\n";
        $content .= "§7  1. Crie seu terreno com /proteger\n";
        $content .= "§7  2. Upe de rank no /rankup\n";
        $content .= "§7  3. Volte no /proteger e clique em\n";
        $content .= "§7     'AUMENTAR TERRENO'\n";
        $content .= "§7  4. Seu terreno cresce +8x8!\n";
        $content .= "§f\n";
        $content .= "§8§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬";

        $form->setContent($content);
        $form->setButton1("§7← Voltar");
        $form->setButton2("§7Fechar");

        $player->sendForm($form);
    }
}
