<?php

declare(strict_types=1);

namespace LandProtect;

use pocketmine\plugin\PluginBase;
use LandProtect\commands\ProtegerCommand;
use LandProtect\commands\ProtegerAdminCommand;
use LandProtect\managers\ClaimManager;
use LandProtect\managers\EconomyManager;
use LandProtect\managers\RankManager;
use LandProtect\listeners\ProtectionListener;
use LandProtect\tasks\SaveDataTask;
use LandProtect\tasks\ParticleTask;

class Main extends PluginBase {

    private static Main $instance;
    private ClaimManager $claimManager;
    private EconomyManager $economyManager;
    private RankManager $rankManager;

    public static function getInstance(): Main {
        return self::$instance;
    }

    protected function onLoad(): void {
        self::$instance = $this;
    }

    protected function onEnable(): void {
        $this->saveDefaultConfig();
        
        // Inicializar managers
        $this->claimManager = new ClaimManager($this);
        $this->economyManager = new EconomyManager($this);
        $this->rankManager = new RankManager($this);
        
        // Registrar eventos
        $this->getServer()->getPluginManager()->registerEvents(
            new ProtectionListener($this),
            $this
        );
        
        // Registrar comandos
        $this->getServer()->getCommandMap()->register("landprotect", new ProtegerCommand($this));
        $this->getServer()->getCommandMap()->register("landprotect", new ProtegerAdminCommand($this));
        
        // Tasks
        $saveInterval = (int)($this->getConfig()->get("advanced")["save-interval"] ?? 5);
        $this->getScheduler()->scheduleRepeatingTask(
            new SaveDataTask($this),
            $saveInterval * 60 * 20
        );
        
        if ($this->getConfig()->get("settings")["show-particles"] ?? true) {
            $this->getScheduler()->scheduleRepeatingTask(
                new ParticleTask($this),
                40
            );
        }
        
        $this->getLogger()->info("§aLandProtect v1.0.0 ativado! §7Minecraft 1.21.60");
    }

    protected function onDisable(): void {
        if (isset($this->claimManager)) {
            $this->claimManager->saveAll();
        }
        $this->getLogger()->info("§cLandProtect desativado.");
    }

    public function getClaimManager(): ClaimManager {
        return $this->claimManager;
    }

    public function getEconomyManager(): EconomyManager {
        return $this->economyManager;
    }

    public function getRankManager(): RankManager {
        return $this->rankManager;
    }

    public function getMessage(string $key, array $replacements = []): string {
        $message = $this->getConfig()->get("messages")[$key] ?? $key;
        foreach ($replacements as $search => $replace) {
            $message = str_replace("{{$search}}", (string)$replace, $message);
        }
        return $message;
    }

    public function getPrefix(): string {
        return $this->getConfig()->get("messages")["prefix"] ?? "§8[§bLand§8] §r";
    }
}
