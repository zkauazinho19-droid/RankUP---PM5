<?php

declare(strict_types=1);

namespace LandProtect\listeners;

use pocketmine\event\Listener;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\player\Player;
use pocketmine\entity\Living;
use LandProtect\Main;

class ProtectionListener implements Listener {

    private Main $plugin;
    private array $lastClaim = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onBlockBreak(BlockBreakEvent $event): void {
        if (!$this->plugin->getConfig()->get("protections")["block-break"]) {
            return;
        }

        $player = $event->getPlayer();
        if ($player->hasPermission("landprotect.bypass")) {
            return;
        }

        $claim = $this->plugin->getClaimManager()->getClaimAt($event->getBlock()->getPosition());
        if ($claim === null) {
            return;
        }

        if (!$claim->hasAccess($player->getName())) {
            $event->cancel();
            $player->sendMessage($this->plugin->getMessage("cannot-break"));
            $player->sendMessage($this->plugin->getMessage("protected-area", ["owner" => $claim->getOwner()]));
        }
    }

    public function onBlockPlace(BlockPlaceEvent $event): void {
        if (!$this->plugin->getConfig()->get("protections")["block-place"]) {
            return;
        }

        $player = $event->getPlayer();
        if ($player->hasPermission("landprotect.bypass")) {
            return;
        }

        $claim = $this->plugin->getClaimManager()->getClaimAt($event->getBlock()->getPosition());
        if ($claim === null) {
            return;
        }

        if (!$claim->hasAccess($player->getName())) {
            $event->cancel();
            $player->sendMessage($this->plugin->getMessage("cannot-place"));
            $player->sendMessage($this->plugin->getMessage("protected-area", ["owner" => $claim->getOwner()]));
        }
    }

    public function onInteract(PlayerInteractEvent $event): void {
        if (!$this->plugin->getConfig()->get("protections")["block-interact"]) {
            return;
        }

        $player = $event->getPlayer();
        if ($player->hasPermission("landprotect.bypass")) {
            return;
        }

        $block = $event->getBlock();
        $claim = $this->plugin->getClaimManager()->getClaimAt($block->getPosition());
        
        if ($claim === null) {
            return;
        }

        if (!$claim->hasAccess($player->getName())) {
            $event->cancel();
            $player->sendMessage($this->plugin->getMessage("cannot-interact"));
            $player->sendMessage($this->plugin->getMessage("protected-area", ["owner" => $claim->getOwner()]));
        }
    }

    public function onEntityDamage(EntityDamageEvent $event): void {
        if (!($event instanceof EntityDamageByEntityEvent)) {
            return;
        }

        $entity = $event->getEntity();
        $damager = $event->getDamager();

        if (!($damager instanceof Player)) {
            return;
        }

        // PVP está sempre ATIVO (como você pediu)
        if ($entity instanceof Player) {
            // Permitir PVP
            return;
        }

        // Proteção de mobs
        if ($entity instanceof Living && !($entity instanceof Player)) {
            if (!$this->plugin->getConfig()->get("protections")["block-mob-damage"]) {
                return;
            }

            if ($damager->hasPermission("landprotect.bypass")) {
                return;
            }

            $claim = $this->plugin->getClaimManager()->getClaimAt($entity->getPosition());
            if ($claim === null) {
                return;
            }

            if (!$claim->hasAccess($damager->getName())) {
                $event->cancel();
                $damager->sendMessage($this->plugin->getMessage("cannot-damage-mob"));
                $damager->sendMessage($this->plugin->getMessage("protected-area", ["owner" => $claim->getOwner()]));
            }
        }
    }

    public function onPlayerMove(PlayerMoveEvent $event): void {
        if (!$this->plugin->getConfig()->get("advanced")["show-enter-leave-messages"]) {
            return;
        }

        $player = $event->getPlayer();
        $from = $event->getFrom();
        $to = $event->getTo();

        $claimFrom = $this->plugin->getClaimManager()->getClaimAt($from);
        $claimTo = $this->plugin->getClaimManager()->getClaimAt($to);

        $playerName = $player->getName();

        // Saindo de um claim
        if ($claimFrom !== null && $claimTo === null) {
            $player->sendTip($this->plugin->getMessage("leaving-claim", ["owner" => $claimFrom->getOwner()]));
            unset($this->lastClaim[$playerName]);
        }

        // Entrando em um claim
        if ($claimFrom === null && $claimTo !== null) {
            $player->sendTip($this->plugin->getMessage("entering-claim", ["owner" => $claimTo->getOwner()]));
            $this->lastClaim[$playerName] = $claimTo->getOwner();
        }

        // Mudando de claim
        if ($claimFrom !== null && $claimTo !== null && $claimFrom !== $claimTo) {
            $player->sendTip($this->plugin->getMessage("entering-claim", ["owner" => $claimTo->getOwner()]));
            $this->lastClaim[$playerName] = $claimTo->getOwner();
        }
    }
}
