<?php

declare(strict_types=1);

namespace LandProtect\models;

class Claim {

    private string $owner;
    private string $world;
    private int $centerX;
    private int $centerZ;
    private int $size;
    private array $members = [];
    private int $createdAt;

    public function __construct(
        string $owner,
        string $world,
        int $centerX,
        int $centerZ,
        int $size
    ) {
        $this->owner = $owner;
        $this->world = $world;
        $this->centerX = $centerX;
        $this->centerZ = $centerZ;
        $this->size = $size;
        $this->createdAt = time();
    }

    public function getOwner(): string {
        return $this->owner;
    }

    public function getWorld(): string {
        return $this->world;
    }

    public function getCenterX(): int {
        return $this->centerX;
    }

    public function getCenterZ(): int {
        return $this->centerZ;
    }

    public function getSize(): int {
        return $this->size;
    }

    public function setSize(int $size): void {
        $this->size = $size;
    }

    public function getMembers(): array {
        return $this->members;
    }

    public function addMember(string $playerName): void {
        if (!in_array($playerName, $this->members, true)) {
            $this->members[] = $playerName;
        }
    }

    public function removeMember(string $playerName): void {
        $key = array_search($playerName, $this->members, true);
        if ($key !== false) {
            unset($this->members[$key]);
            $this->members = array_values($this->members);
        }
    }

    public function isMember(string $playerName): bool {
        return in_array($playerName, $this->members, true);
    }

    public function isOwner(string $playerName): bool {
        return $this->owner === $playerName;
    }

    public function hasAccess(string $playerName): bool {
        return $this->isOwner($playerName) || $this->isMember($playerName);
    }

    public function isInside(int $x, int $z): bool {
        $halfSize = (int)($this->size / 2);
        return abs($x - $this->centerX) <= $halfSize && abs($z - $this->centerZ) <= $halfSize;
    }

    public function overlaps(Claim $other): bool {
        if ($this->world !== $other->world) {
            return false;
        }

        $halfSize1 = (int)($this->size / 2);
        $halfSize2 = (int)($other->size / 2);

        return abs($this->centerX - $other->centerX) < ($halfSize1 + $halfSize2) &&
               abs($this->centerZ - $other->centerZ) < ($halfSize1 + $halfSize2);
    }

    public function distanceTo(Claim $other): float {
        if ($this->world !== $other->world) {
            return PHP_FLOAT_MAX;
        }

        $dx = $this->centerX - $other->centerX;
        $dz = $this->centerZ - $other->centerZ;
        return sqrt($dx * $dx + $dz * $dz);
    }

    public function getMinX(): int {
        return $this->centerX - (int)($this->size / 2);
    }

    public function getMaxX(): int {
        return $this->centerX + (int)($this->size / 2);
    }

    public function getMinZ(): int {
        return $this->centerZ - (int)($this->size / 2);
    }

    public function getMaxZ(): int {
        return $this->centerZ + (int)($this->size / 2);
    }

    public function getCreatedAt(): int {
        return $this->createdAt;
    }

    public function toArray(): array {
        return [
            "owner" => $this->owner,
            "world" => $this->world,
            "centerX" => $this->centerX,
            "centerZ" => $this->centerZ,
            "size" => $this->size,
            "members" => $this->members,
            "createdAt" => $this->createdAt
        ];
    }

    public static function fromArray(array $data): self {
        $claim = new self(
            $data["owner"],
            $data["world"],
            $data["centerX"],
            $data["centerZ"],
            $data["size"]
        );
        $claim->members = $data["members"] ?? [];
        $claim->createdAt = $data["createdAt"] ?? time();
        return $claim;
    }
}
