<?php

declare(strict_types=1);

namespace LandProtect\commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use LandProtect\Main;

class ProtegerAdminCommand extends Command {

    private Main $plugin;

    public function __construct(Main $plugin) {
        parent::__construct("protegeradmin", "Admin de terrenos", "/protegeradmin");
        $this->setPermission("landprotect.admin");
        $this->plugin = $plugin;
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cApenas jogadores podem usar este comando!");
            return false;
        }

        if (!$sender->hasPermission("landprotect.admin")) {
            $sender->sendMessage("§cVocê não tem permissão!");
            return false;
        }

        $sender->sendMessage("§aComandos admin em desenvolvimento!");
        return true;
    }
}
